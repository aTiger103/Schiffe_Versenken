#ifndef CPP_GLOBALS_H 
#define CPP_GLOBALS_H 

#include "CppRandom.hpp"

extern Random globalRandom; 

#endif