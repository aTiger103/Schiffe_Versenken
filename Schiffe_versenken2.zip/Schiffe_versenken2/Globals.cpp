#include "Globals.hpp"

Random globalRandom;